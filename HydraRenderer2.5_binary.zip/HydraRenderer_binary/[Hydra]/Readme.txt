﻿Инструкция по установки portable версии:

1. Скачайте отсюда файлы: https://github.com/Ray-Tracing-Systems/HydraMaxBinary
2. Скопируйте папку [Hydra] в корень диска С.
3. Скопируйте файлы из папок "max20xx", в папку плагинов вашего 3д макса. Например из "max2019" в "c:\Program Files\Autodesk\3ds Max 2019\Plugins\"


Если возникли проблемы с запуском, посмотрите пожалуйста информацию по установке и решению проблем в документации:
https://docs.google.com/document/d/1e41g3ICw4sUX0fIyjihNz6xheJtKeElac0JNa_2n-4M/edit#


Начальные основы работы можно посмотреть на нашем сайте:
http://www.raytracing.ru/3dsmax.html


Если у Вас возникла какая-то ошибка при работе с рендером, или при его установке, которую вы не смогли решить, напишите нам об этом:
info@raytracing.ru
